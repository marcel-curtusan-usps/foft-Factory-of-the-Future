﻿using System;

namespace Factory_of_the_Future.DockDoor
{
    public partial class DockDoor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Method intentionally left empty.
        }
    }
}